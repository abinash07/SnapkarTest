<?php
session_start();
if(!isset($_SESSION["sbuserid"])){
header("location:login");
}else{
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@700&family=Roboto&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/style.css">
	<style>
		.profileimage{
			text-align: center;
			padding: 50px 0 20px 0;
			position: relative;
		}
		.profileimage img{
			width: 150px;
			height: 150px;
			border-radius: 100%;
			object-fit: cover;
			border: 4px solid #E4E7FA;
		}
		.bottom-right {
			position: absolute;
			bottom: 12px;
			right: 37%;
			background-color: #FFFFFF;
			box-shadow: 0 1px 3px #c7c7c7;
			padding: 5px 10px;
			border-radius: 3px;
		}
		.fa-camera{
			color: #0B7DDA;
		}
		#verified{
			/*  background-color: red;*/
			font-size: 14px;
			color: #0B7DDA;
			padding-top: -100px;
		}
		.snapprofiledetails{
			text-align: center;
		}
		.snapprofiledetails h2{
			font-family: 'Open Sans', sans-serif;
		}
		.snapprofiledetails h3{
			color: #595959;
			font-size: 15px;
			font-family: 'Open Sans', sans-serif;
		}
		.snapprofilebuttons{
			width: 95%;
			text-align: center;
			margin: 30px auto 20px auto;
			display: inline-block;
		}
		.snapprofilebutton{
			display: inline-block;
			text-align: center;
		}
		#snapprofilebuttons{
			border: none;
			color: #FFFFFF;
			padding: 7px 15px;
			border-radius: 3px;
			margin: 5px;
			background-color: #0B7DDA;
			text-align: center;
			font-family: 'Roboto', sans-serif;
		}
		#snapprofilebuttonsf{
			border: none;
			color: #FFFFFF;
			padding: 7px 15px;
			border-radius: 3px;
			margin: 5px;
			background-color: #0B7DDA;
			text-align: center;
			font-family: 'Roboto', sans-serif;
		}
		#snapprofileicon{
			border: none;
			color: #FFFFFF;
			padding: 7px 10px;
			border-radius: 3px;
			margin: 5px;
			background-color: #0B7DDA;
			text-align: center;
			font-family: 'Roboto', sans-serif;
		}
		.snapprofile::after {
			content: "";
			clear: both;
			display: table;
		}

		.follow{
			width: 95%;
			margin: 5px 2.5% 20px 2.5%;
			text-align: center;
			box-sizing: border-box;
		}
		.follow a{
			color: #000000;
		}
		.ftake{
			float: left;
			width: 33%;
			border: solid #F0F0F0;
			border-width: 1px 1px 1px 0;
		}
		.follower{
			float: left;
			width: 33%;
			border: solid #F0F0F0;
			border-width: 1px 1px 1px 0;
		}
		.following{
			float: left;
			width: 33%;
			border: solid #F0F0F0;
			border-width: 1px 0 1px 0;
		}
		#ftakes{
			font-size: 14px;
			padding: 5px 0 5px 0;
			font-family: 'Open Sans', sans-serif;
		}
		#fnumber{
			padding: 0 0 5px 0;
			font-size: 14px;
		}
		.follow::after {
			content: "";
			clear: both;
			display: table;
		}




		.intro{
			width: 95%;
			margin: 5px 2.5% 10px 2.5%;
		}
		#intro{
			font-size: 15px;
			padding: 0 0 15px 0;
			font-family: 'Open Sans', sans-serif;
		}
		.intro pre{
			white-space: pre-wrap;
			overflow: auto;
			padding: 1px 0 5px 0;
			text-align: left;
			line-height: 1.5;
			overflow: hidden;
			font-family: 'Roboto', sans-serif;
			color: #262626;
			font-size: 14px;
			margin-top: -10px;
		}
		#addintro{
			text-decoration: none;
			color: #0B7DDA;
		}
		.intro pre a{
			color: #0B7DDA;
			text-decoration: none;
		}
		.introp{
			font-size: 14px;
			padding-bottom: 5px;
		}
		.introhead{
			font-size: 14px;
			font-family: 'Open Sans', sans-serif;
		}
		.city{
			color: #262626;
		}
		.introlink{
			color: #0B7DDA;
			text-decoration: none;
		}
		.fa-globe{
			color: #0B7DDA;
		}
		.fa-map-marker{
			color: red;
		}
		#location{
			color: #1877F2;
		}

		#firtshome{
			background-color: #fafafa;
		}

		#modal-form h3{
			text-align: center;
			margin: 15px 0 0 0;
			padding-bottom: 10px;
			font-size: 14px;
			font-family: 'Open Sans', sans-serif;
		}
		.sharebox1 a{
			display: inline;
		}
		#sharenew1{
			border: 1px solid #f0f0f0;
			padding: 5px 10px;
		}





		.topmenu{
			width: 95%;
			margin: 10px 2.5% 10px 2.5%;
			overflow: auto;
			white-space: nowrap;
		}
		.topmenu a{
			display: inline-block;
			color: #3F3A64;
			text-align: center;
			padding: 5px 10px;
			text-decoration: none;
			border: 1px solid #F0F0F0;
			border-radius: 5px;
			margin: 10px 15px 10px 0;
		}
		.topmenu a:hover{
			color: #3F3A64;
			background-color: #F0F0F0;
		}
		.active{
			background-color: #F0F0F0;
		}
		#now{
			color: #0B7DDA;
		}
		.topmenu:after {
			content: "";
			display: table;
			clear:both;
		}



		.edit{
			float: right;
			color: #0B7DDA!important;
			font-size: 16px;
		}
		#edit{
			color: #FFFFFF;
			font-size: 12px;
			padding: 6px 10px;
			border-radius: 5px;
			display: inline-block;
			margin: 0px 5px 5px 0;
			background-color: #0B7DDA;
		}
		.likes{
			width: 95%;
			margin: 5px 2.5% 20px 2.5%;
		}
		.likes a{
			color: #262626;
			text-decoration: none;
		}
		#likes{
			font-size: 14px;
			padding: 5px 10px;
			border-radius: 5px;
			display: inline-block;
			margin: 5px 5px 5px 0;
			background-color: #f0f0f0;
		}
		.likes::after {
			content: "";
			clear: both;
			display: table;
		}
		@media only screen and (min-width: 750px) {
			article{
				width: 52%;
				float: left;
				margin-left: 18%;
			}
		}



		#more{
			background: rgba(0,0,0,0.7);
			position: fixed;
			left: 0;
			top:0;
			width: 100%;
			height: 100%;
			z-index: 1;
			display: none;
			overflow-y: scroll;
		}
		#more::-webkit-scrollbar{
			display: none;
		}

		#modal-more{
			width: 80%;
			position: relative;
			background-color: #FFFFFF;
			top: 10%;
			left: 10%;
			padding: 15px;
			border-radius: 4px;
			text-align: center;
			margin-bottom: 10px;
		}
		#modal-more a{
			text-decoration: none;
			color: #0B7DDA;
			line-height: 1.5;
			display: inline-block;
		}
		#modal-more p{
			text-align: center;
			margin: 15px 0 0 0;
			padding-bottom: 10px;
			font-size: 14px;
			font-family: 'Open Sans', sans-serif;
		}
		#modal-more hr{
			width: 100%;
			border: solid #F0F0F0;
			border-width: 1px 0 0;
		/*	margin: 15px 0;*/
		}
		#cross{
			font-size: 20px;
			color: #262626;
			position: absolute;
			top: 6px;
			right: 2.5%;
			cursor: pointer;
		}
		@media (min-width: 600px){
			#modal-more{
				width: 35%;
				position: relative;
				background-color: #FFFFFF;
				top: 10%;
				left: 32.5%;
				padding: 15px;
				border-radius: 4px;
				text-align: center;
				margin-bottom: 10px;
			}
		}

	</style>
</head>
<body>
	<?php require_once('connect.php'); ?>

	<?php
		$slamuserid = $_SESSION["sbuserid"]; 
		$query = "select * from user where userid='$slamuserid'";
		$run = mysqli_query($con,$query);
		$row = mysqli_fetch_array($run);
		$userid = $row['userid'];
		$image = $row['image'];


		$username = mysqli_real_escape_string($con,@$_GET['username']);
		$username = htmlentities($username);

		$query2 = "SELECT u.name, u.userid, ui.image, ui.bluetick, COUNT(uv.id) as view, COUNT(fw.id) as follower, COUNT(fg.id) as following FROM user as u LEFT JOIN userinfo as ui ON u.userid = ui.userid LEFT JOIN userview as uv ON u.userid = uv.profileid LEFT JOIN follow as fw ON u.userid = fw.following LEFT JOIN follow as fg ON u.userid = fg.follower WHERE u.username = '$username'";
		$run2 = mysqli_query($con,$query2);
		$row2 = mysqli_fetch_array($run2);
		$name = $row2['name'];
		$snickuserid = $row2['userid'];
		$snickimage = $row2['image'];
		$verify = $row2['bluetick'];
		$view = $row2['view'];


		if($view > 0){
			$query3 = "UPDATE userview SET nocount = nocount+1 where profileid = '$snickuserid'";
		}else{
			$query3 = "INSERT INTO userview (profileid, userid, nocount) VALUES ('$snickuserid','$userid',1)";
		}
		$run3 = mysqli_query($con,$query3);


		

		$query4 = "select * from follow where following='$snickuserid'";
		$run4 = mysqli_query($con,$query4);
		$follower = mysqli_num_rows($run4);

		$query5 = "select * from follow where follower='$snickuserid'";
		$run5 = mysqli_query($con,$query5);
		$following = mysqli_num_rows($run5);

	?>
	<div class="top">
		<p id="bar" onclick="opennav()" ><i class="fa fa-long-arrow-left"></i></p>
		<a id="snap" href="<?php echo $baseurl; ?>/index">Profile</a>
		<a id="img" href="<?php echo $baseurl; ?>/home/myaccount"><img src="<?php echo $baseurl; ?>/userprofile/<?php echo $image; ?>"></a>
		<a id="card" href="menu"><i class="fa fa-th"></i></a>
		<a id="top29" href="index">Search</a>
		<a id="top29" href="home/addpost">New Post</a>
		<a id="top29" href="home/explore">Explore</a>
		<a id="top29" href="index">Home</a>
	</div>
	<div class="space"></div>

	<section>
		<div class="leftbar">
			<br>
			<a href="index.php"> <i id="ioconf" class="fa fa-home"></i> Home</a>
			<a href="home/myaccount"><i id="ioconf" class="fa fa-user-plus"></i> My Account</a>
			<a href="home/myaccount"><i id="ioconf" class="fa fa-user-circle-o"></i> My Posts</a>
			<a href="home/addpost"><i id="ioconf" class="fa fa-plus"></i> Create New Post</a>
			<hr>
			<a href="home/search"><i id="ioconf" class="fa fa-search"></i> Search</a>
			<a href="home/saved"><i id="ioconf" class="fa fa-bookmark-o"></i> My Saved </a>
			<a href="home/explore"><i id="ioconf" class="fa fa-compass"></i> Explore</a>
			<a href="home/addpost"><i id="ioconf" class="fa fa-plus"></i> New Post</a>
			<hr>
			<a href="aboutus"><i id="ioconf" class="fa fa-info-circle"></i> About us</a>
			<a href="mailto:thesnapkar@gmail.com"><i id="ioconf" class="fa fa-envelope"></i> Contact us</a>
			<a href="term"><i id="ioconf" class="fa fa-legal"></i> Term & Condition</a>
			<a href="privacy"><i id="ioconf" class="fa fa-lock"></i> Privacy policy</a>
		</div>
		<article>
			<div class="snapprofile">
				<div class="profileimage">
					<img src="<?php echo $baseurl; ?>/userprofile/<?php echo $snickimage; ?>" alt="Snapkar">
				</div>
				<div class="snapprofiledetails">
					<h2><?php echo $name; ?> <?php if ($verify==1) {  ?><span id="verified"><i class="fa fa-check-circle"></i></span><?php } ?></h2>
					<h3>@<?php echo $username; ?></h3>
				</div>
				<div class="snapprofilebuttons">
					<div class="snapprofilebutton">
				        <?php
				        $query11 = "select * from follow where follower='$userid' and following='$userid'";
				        $run11 = mysqli_query($con,$query11);
				        if(mysqli_num_rows($run11) > 0){
				        ?>
				        <button id="snapprofilebuttons"><i class="fa fa-user"></i> Following</button>
				      <?php }else{ ?>
				        <button id="snapprofilebuttonsf" onclick="followme('<?php echo $snickuserid; ?>');">
				          <span id='changeme'><i class="fa fa-user-plus"></i> Follow </span>
				        </button>
				      <?php } ?>
					</div>
					<div class="snapprofilebutton">
						<a href="editinfo"><button id="snapprofilebuttons"><i class="fa fa-envelope"></i> Knock</button></a>
					</div>
					<div class="snapprofilebutton notifi">
						<button id="snapprofileicon" onclick="moreit();"><i class="fa fa-ellipsis-v"></i></button>
					</div>
				</div>
			</div>

				<div id="more">
					<div id="modal-more">
						<p><a href="">Report</a></p>
						<hr>
						<p><a href="">View profile</a></p>
						<hr>
						<p><a href="">Send Knock</a></p>
						<hr>
						<p><a href="">Report</a></p>
						<hr>
						<div id="cross" onclick='closeit();'><i class="fa fa-times"></i></div>
						<p onclick='closeit();'>Cancel</p>
					</div>
				</div>

			<div class="follow">
				<div class="ftake">
					<p id="ftakes">Views</p>
					<p id="fnumber"><?php echo $view; ?></p>
				</div>
				<a href="myfollowers">
					<div class="follower">
						<p id="ftakes">Followers</p>
						<p id="fnumber"><span id="followers"><?php echo $follower; ?></span></p>
					</div>
				</a>
				<a href="myfollowing">
					<div class="following">
						<p id="ftakes">Following</p>
						<p id="fnumber"><?php echo $following; ?></p>
					</div>
				</a>
			</div>

			<?php
				$query = "SELECT * FROM aboutme WHERE userid = '$snickuserid'";
				$run = mysqli_query($con, $query);
				$row = mysqli_fetch_array($run);
				$bio = @$row['bio'];
				$occupation = @$row['occupation'];
				$dob = @$row['dob'];
				$living = @$row['living'];

				$query10 = "SELECT * FROM work WHERE userid = '$snickuserid' order by 1 desc limit 1";
				$run10 = mysqli_query($con, $query10);

				$query11 = "SELECT * FROM education WHERE userid = '$snickuserid' order by 1 desc limit 1";
				$run11 = mysqli_query($con, $query11);
			?>
			<div class="intro">
				<p id="intro">About Me</p>
				<?php if(!empty($bio)){ ?><pre><span id="lintro"><?php echo $bio; ?></span></pre><?php } ?>
				<?php if(!empty($occupation)){ ?><p class="introp"><span class="introhead">Occupation:</span> <span class="city"><?php echo $occupation; ?></span></p><?php } ?>

				<?php if(mysqli_num_rows($run10) > 0){ $row10 = mysqli_fetch_array($run10); ?>
					<p class="introp"><span class="introhead">Work:</span> <span class="city"><?php echo $row10['work']; ?></span></p>
				<?php } ?>

				<?php if(mysqli_num_rows($run11) > 0){ $row11 = mysqli_fetch_array($run11); ?>
					<p class="introp"><span class="introhead">Education:</span> <span class="city"><?php echo $row11['education']; ?></span></p>
				<?php } ?>

				<?php if(!empty($living)){ ?><p class="introp"><span class="introhead">Living city:</span> <span class="city"><?php echo $living; ?></span></p><?php } ?>

				<p class="introp"><a class="introlink" href="editinfo"><span class="introhead">See more details...</span></a></p>
			</div>

			<div class="likes">
				<p id="intro">Likes / Intrests</p>
				<?php
					$query2 = "SELECT * FROM intrests WHERE userid = '$snickuserid'";
					$run2 = mysqli_query($con, $query2);
					if(mysqli_num_rows($run2) > 0){
					while($row2 = mysqli_fetch_array($run2)){
				?>
					<p id="likes"><?php echo $row2['intrest']; ?></p>
				<?php } }else{ ?>
					<a id="edit" href="interest"><i class="fa fa-plus"></i> No likes added</a>
				<?php } ?>
			</div>

		</article>
	</section>
	<?php include('bottom.php'); ?>
	<script>
		const opennav = () =>{
			history.go(-1);
		}

		function followme(following){
			$("#snapprofilebuttonsf").prop("onclick", null).off("click");
			$("#changeme").html('<i class="fa fa-user"></i> Following');
			var count_follow = $("#followers").html();
			count_follow++;
			$("#followers").html(count_follow);

			$.ajax({
				url : "ajax/followme",
				type : "POST",
				data : {following: following},
				cache: false,
				success: function(data){
				}
			});
		}

		function moreit(){
			var x = document.getElementById("more");
			x.style.display = "block";
		}
		function closeit(){
			var x = document.getElementById("more");
			x.style.display = "none";
		}

	</script>
</body>
</html>
<?php } ?>