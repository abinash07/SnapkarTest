<div class="bspace"></div>
<div class="footmenu">
  <a id="footb" href="index">
  <div class="fmenu1">
    <p><i id="home" class="fa fa-home"></i></p>
  </div>
  </a>
  <a href="search">
  <div class="fmenu1">
    <p><i id="compass" class="fa fa-search"></i></p>
  </div>
</a>
<a href="home/addpost">
  <div class="fmenu1">
    <p><i id="book" class="fa fa-plus"></i></p>
  </div>
</a>
<a href="home/location">
  <div class="fmenu1">
    <p><i id="book" class="fa fa-compass"></i></p>
  </div>
</a>
<a href="home/notification">
  <div class="fmenu1 bell">
    <p><i id="bell" class="fa fa-bell"></i></p>
    <div class="bell1"><i class="fa fa-circle"></i></div>
  </div>
</a>
</div>