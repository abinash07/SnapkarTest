<?php 
require_once("../connect.php");
if(isset($_POST['sbtokenp'])){

    $sbtokenp = mysqli_real_escape_string($con,$_POST['sbtokenp']);
    $sbtokenp = htmlentities($sbtokenp);

    $query = "select * from user where userid='$sbtokenp'";
    $run = mysqli_query($con,$query);
    $row = mysqli_fetch_array($run);
    $name = $row['name'];
    $image = $row['image'];
}
?>
<p id="shead">Recent Logins</p>
<div class="slambook">
    <div class="simg">
        <img src="userprofile/<?php echo $image; ?>">
    </div>
    <div class="stext">
        <p id="stext2"><?php echo $name;?></p>
        <p id="stext3">Click Here to direct login</p>
    </div>
</div>