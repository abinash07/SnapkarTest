<?php
ob_start();
session_start();

  require_once("../connect.php");
  if(isset($_POST['sbtokenp']) ){

    $sbtokenp = mysqli_real_escape_string($con,$_POST['sbtokenp']);
    $sbtokenp = htmlentities($sbtokenp);

    $query = "select * from user where userid='$sbtokenp'";
    $run = mysqli_query($con,$query);
    $row = mysqli_fetch_array($run);
    $userid = $row['userid'];
    $name = $row['name'];
    $image = $row['image'];

    $_SESSION["sbuserid"]= $userid;

  	if(isset($_SESSION["sbuserid"])){
  		echo 1;
  	}else{
  		echo 0;
  	}    
  }
?>