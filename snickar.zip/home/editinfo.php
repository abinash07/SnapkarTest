<?php
session_start();
if(!isset($_SESSION["sbuserid"])){
header("location:login");
}else{
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@700&family=Roboto&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="../assets/css/style.css">
	<style>
		.about{
			width: 95%;
			margin: 10px 2.5%;
		}
		#ahead{
			font-size: 14px;
			padding: 0 0 5px 0;
			font-family: 'Open Sans', sans-serif;
		}
		.about pre{
			white-space: pre-wrap;
			overflow: auto;
			padding: 1px 0 5px 0;
			text-align: left;
			line-height: 1.5;
			overflow: hidden;
			font-family: 'Roboto', sans-serif;
			color: #262626;
			font-size: 14px;
		}
		.about p{
			font-size: 14px;
			padding-bottom: 10px;
		}
		.about button{
			width: 100%;
			border: none;
			padding: 10px 0;
			border-radius: 5px;
			background-color: #F0F0F0;
		}
		.edit{
			float: right;
			color: #0B7DDA;
			font-size: 20px;
		}
		.add{
			color: #0B7DDA;
			padding: 0 4px;
			font-size: 12px;
			margin-left: 5px;
			border-radius: 100%;
			background-color: #F0F0F0;
		}
		.intro hr{
			width: 95%;
			margin-left: 2.5%;
			border: solid #F0F0F0;
			border-width: 1px 0 0;
		}





		.search{
	        width: 100%;
	        box-sizing: border-box;
	        padding: 1px 0 1px 0;
	    }
	    .search form{
	        margin: 10px 0 10px 0;
	        text-align:center;
	        box-sizing: border-box;
	        border: 1px solid #F0F0F0;
	        border-radius: 5px;
	    }
	    .search form.example input[type=text]{
	        padding: 13px 0 10px 2%;
	        font-size: 14px;
	        float: left;
	        width: 85%;
	        border: none;
	        background: #FFFFFF;
	        border-radius: 5px 0 0 5px;
	        outline: none;
	        box-sizing: border-box;
	    }
	    .search form.example button {
	        float: right;
	        width: 15%;
	        color: #FFFFFF;
	        font-size: 15px;
	        border: none;
	        border-left: none;
	        cursor: pointer;
	        border-radius: 0 5px 5px 0;
	        background-color: #0B7DDA;
	        padding: 10.8px 10px 10.8px 10px;
	    }
	    .search form.example button:hover {
	        opacity: 0.8;	    }
	    .search form.example::after {
	        content: "";
	        clear: both;
	        display: table;
	    }
		.errormsg{
			color: red;
			font-size: 14px;
		}

	</style>
</head>
<body>
	<?php
		require_once('../connect.php');
		$slamuserid = $_SESSION["sbuserid"]; 
		$query = "select * from user where userid='$slamuserid'";
		$run = mysqli_query($con,$query);
		$row = mysqli_fetch_array($run);
		$name = $row['name'];
		$username = $row['username'];
		$userid = $row['userid'];
		$image = $row['image'];
		$verify = $row['verify'];
	?>
	<div class="top">
		<p id="bar" onclick="opennav()" ><i class="fa fa-long-arrow-left"></i></p>
		<a id="snap" href="<?php echo $baseurl; ?>/index">About me</a>
		<a id="img" href="<?php echo $baseurl; ?>/home/myaccount"><img src="<?php echo $baseurl; ?>/profile/<?php echo $image; ?>"></a>
		<a id="card"href="home/addpost"><i class="fa fa-th"></i></a>
		<a id="top29" href="index">Search</a>
		<a id="top29" href="home/addpost">New Post</a>
		<a id="top29" href="home/explore">Explore</a>
		<a id="top29" href="index">Home</a>
	</div>
	<div class="space"></div>

	<section>
		<div class="leftbar">
			<br>
			<a href="index.php"> <i id="ioconf" class="fa fa-home"></i> Home</a>
			<a href="home/myaccount"><i id="ioconf" class="fa fa-user-plus"></i> My Account</a>
			<a href="home/myaccount"><i id="ioconf" class="fa fa-user-circle-o"></i> My Posts</a>
			<a href="home/addpost"><i id="ioconf" class="fa fa-plus"></i> Create New Post</a>
			<hr>
			<a href="home/search"><i id="ioconf" class="fa fa-search"></i> Search</a>
			<a href="home/saved"><i id="ioconf" class="fa fa-bookmark-o"></i> My Saved </a>
			<a href="home/explore"><i id="ioconf" class="fa fa-compass"></i> Explore</a>
			<a href="home/addpost"><i id="ioconf" class="fa fa-plus"></i> New Post</a>
			<hr>
			<a href="aboutus"><i id="ioconf" class="fa fa-info-circle"></i> About us</a>
			<a href="mailto:thesnapkar@gmail.com"><i id="ioconf" class="fa fa-envelope"></i> Contact us</a>
			<a href="term"><i id="ioconf" class="fa fa-legal"></i> Term & Condition</a>
			<a href="privacy"><i id="ioconf" class="fa fa-lock"></i> Privacy policy</a>
		</div>
		<article>

			<div class="intro">
				<?php
					$query = "SELECT * FROM aboutme WHERE userid='$slamuserid'";
					$run = mysqli_query($con, $query);
					if(mysqli_num_rows($run) > 0){
						$row = mysqli_fetch_array($run);
						$bio = $row['bio'];
						$occupation = $row['occupation'];
						$dob = date('d M, Y',strtotime($row['dob']));
						$localname = $row['localname'];
						$living = $row['living'];
						$home = $row['home'];
						$button = '<i class="fa fa-pencil"></i> Edit';
					}else{
						$bio = 'No record';
						$occupation = 'No record';
						$dob = 'No record';
						$localname = 'No record';
						$living = 'No record';
						$home = 'No record';
						$button = '<i class="fa fa-plus"></i> Add';
					}
				?>
				<div class="about">
					<p id="ahead">Bio</p>
					<pre><?php echo $bio; ?></pre>
				</div>
				<div class="about">
					<p id="ahead">Occupation</p>
					<p><?php echo $occupation; ?></p>
				</div>
				<div class="about">
					<p id="ahead">DOB</p>
					<p><?php echo $dob; ?></p>
				</div>
				<div class="about">
					<p id="ahead">Local Name</p>
					<p><?php echo $localname; ?></p>
				</div>
				<div class="about">
					<p id="ahead">Living Town</p>
					<p><?php echo $living; ?></p>
				</div>
				<div class="about">
					<p id="ahead">Home Town</p>
					<p><?php echo $home; ?></p>
				</div>
				<div class="about">
					<a href="editbio"><button><?php echo $button; ?></button></a>
				</div>
				<hr>

				<div class="about">
					<p id="ahead" style="margin-bottom: 10px;">Work <a class="add" onclick="showForm('work');" href="javascript:void(0);"><i class="fa fa-plus"></i></a></p>
					<div id="showwork"></div>
					<div class="search" id="work" style="display: none;">
						<form class="example" id="workForm">
							<input type="text" id="workname" name="workname" value="" placeholder="Add your work..." required/>
							<button id="addwork" type="submit" name="submit">ADD</button>
						</form>
						<p class="errormsg" id="adderrormsg"></p>
					</div>

					<div class="search" id="editwork" style="display: none;">
						<form class="example" id="editWorkForm">
							<input type="text" id="wditWorkname" name="wditWorkname" value="" placeholder="Add your work..." required/>
							<button id="editworkBtn" onclick="editwbtn();" type="submit" name="submit">SAVE</button>
							<p id="workid" style="display: none;"></p>
						</form>
						<p class="errormsg" id="editworkerrormsg"></p>
					</div>
				</div>
				<hr>
				<div class="about">
					<p id="ahead" style="margin-bottom: 10px;">School / College / Univercity <a class="add" onclick="showForm('college');" href="javascript:void(0);"><i class="fa fa-plus"></i></a></p>
					<div id="showcollege"></div>
					<div class="search" id="college" style="display: none;">
						<form class="example" id="collegeForm">
							<input type="text" id="collegename" name="collegename" value="" placeholder="Add your college..." required/>
							<button id="addcollege" type="submit" name="submit">ADD</button>
						</form>
						<p class="errormsg" id="addcollegemsg"></p>
					</div>

					<div class="search" id="editcollege" style="display: none;">
						<form class="example" id="editcollegeForm">
							<input type="text" id="wditcollegename" name="wditcollegename" value="" placeholder="Edit your college..." required/>
							<button id="editcollegeBtn" onclick="editcbtn();" type="submit" name="submit">SAVE</button>
							<p id="collegeid" style="display: none;"></p>
						</form>
						<p class="errormsg" id="editcollegemsg"></p>
					</div>

				</div>
				<hr>

				<div class="about">
					<p id="ahead" style="margin-bottom: 10px;">Education <a class="add" onclick="showForm('education');" href="javascript:void(0);"><i class="fa fa-plus"></i></a></p>
					<div id="showeducation"></div>
					<div class="search" id="education" style="display: none;">
						<form class="example" id="educationForm">
							<input type="text" id="educationname" name="educationname" value="" placeholder="Add your education..." required/>
							<button id="addeducation" type="submit" name="submit">ADD</button>
						</form>
						<p class="errormsg" id="addeducationmsg"></p>
					</div>

					<div class="search" id="editeducation" style="display: none;">
						<form class="example" id="editeducationForm">
							<input type="text" id="wditeducationname" name="wditeducationname" value="" placeholder="Edit your education..." required/>
							<button id="editeducationBtn" onclick="editebtn();" type="submit" name="submit">SAVE</button>
							<p id="educationid" style="display: none;"></p>
						</form>
						<p class="errormsg" id="editeducationmsg"></p>
					</div>

				</div>
				<hr>


			</div>
		</article>
	</section>
	<?php include('../bottom.php'); ?>
	<script>
		const opennav = () =>{
			history.go(-1);
		}

		function showForm(formid){
			var x = document.getElementById(formid);
			if(x.style.display === "none") {
				x.style.display = "block";
			}else{
				x.style.display = "none";
			}
		}



		function showWork(){
			$.ajax({
				url : "ajax/showwork",
				type : "POST",
				cache: false,
				success: function(data){
					$('#showwork').html(data);
				}
			});
		}
		showWork();

		$('#workForm').submit(function(e){
	    e.preventDefault();
        	var workname = $('#workname').val();
			$.ajax({
				url : "ajax/addwork",
				type : "POST",
				data: {work: workname},
				cache: false,
				beforeSend: function(){
					$('#addwork').attr('disabled', true);
				},
				success: function(data){
					if(data == 1){
						$('#workForm').trigger('reset');
						showWork();
					}else{
						$("#adderrormsg").html("*Something Error Please Try After Some Time Later.");
					}
				},
				complete: function(){
					$('#addwork').attr('disabled', false);
				}
			});
	    });

	    function editwork(id,work){
	    	showForm('editwork');
			$('#wditWorkname').val(work);
			$('#workid').html(id);
	    }

	    function editwbtn(){
	    	var wditWorkname = $('#wditWorkname').val();
	    	var editid = $('#workid').html();
	    	$.ajax({
				url : "ajax/editwork",
				type : "POST",
				data: {editid: editid, work: wditWorkname},
				cache: false,
				beforeSend: function(){
					$('#editworkBtn').attr('disabled', true);
				},
				success: function(data){
					if(data == 1){
						showWork();
						showForm('editwork');
					}else{
						$("#editworkerrormsg").html("*Something Error Please Try After Some Time Later.");
					}
				},
				complete: function(){
					$('#editworkBtn').attr('disabled', false);
				}
			});
	    }




	    function showcollege(){
			$.ajax({
				url : "ajax/showcollege",
				type : "POST",
				cache: false,
				success: function(data){
					$('#showcollege').html(data);
				}
			});
		}
		showcollege();

		$('#collegeForm').submit(function(e){
	    e.preventDefault();
        	var collegename = $('#collegename').val();
			$.ajax({
				url : "ajax/addcollege",
				type : "POST",
				data: {college: collegename},
				cache: false,
				beforeSend: function(){
					$('#addcollege').attr('disabled', true);
				},
				success: function(data){
					if(data == 1){
						$('#collegeForm').trigger('reset');
						showcollege();
					}else{
						$("#addcollegemsg").html("*Something Error Please Try After Some Time Later.");
					}
				},
				complete: function(){
					$('#addcollege').attr('disabled', false);
				}
			});
	    });

	    function editcollege(id,college){
	    	showForm('editcollege');
			$('#wditcollegename').val(college);
			$('#collegeid').html(id);
	    }

	    function editcbtn(){
	    	var wditcollegename = $('#wditcollegename').val();
	    	var editid = $('#collegeid').html();
	    	$.ajax({
				url : "ajax/editcollege",
				type : "POST",
				data: {editid: editid, college: wditcollegename},
				cache: false,
				beforeSend: function(){
					$('#editcollegeBtn').attr('disabled', true);
				},
				success: function(data){
					if(data == 1){
						showcollege();
						showForm('editcollege');
					}else{
						$("#editcollegemsg").html("*Something Error Please Try After Some Time Later.");
					}
				},
				complete: function(){
					$('#editcollegeBtn').attr('disabled', false);
				}
			});
	    }



	    function showeducation(){
			$.ajax({
				url : "ajax/showeducation",
				type : "POST",
				cache: false,
				success: function(data){
					$('#showeducation').html(data);
				}
			});
		}
		showeducation();

		$('#educationForm').submit(function(e){
	    e.preventDefault();
        	var educationname = $('#educationname').val();
			$.ajax({
				url : "ajax/addeducation",
				type : "POST",
				data: {education: educationname},
				cache: false,
				beforeSend: function(){
					$('#addeducation').attr('disabled', true);
				},
				success: function(data){
					if(data == 1){
						$('#educationForm').trigger('reset');
						showeducation();
					}else{
						$("#addeducationmsg").html("*Something Error Please Try After Some Time Later.");
					}
				},
				complete: function(){
					$('#addeducation').attr('disabled', false);
				}
			});
	    });

	    function editeducation(id,education){
	    	showForm('editeducation');
			$('#wditeducationname').val(education);
			$('#educationid').html(id);
	    }
	    
	    function editebtn(){
	    	var wditeducationname = $('#wditeducationname').val();
	    	var editid = $('#educationid').html();
	    	$.ajax({
				url : "ajax/editeducation",
				type : "POST",
				data: {editid: editid, education: wditeducationname},
				cache: false,
				beforeSend: function(){
					$('#editeducationBtn').attr('disabled', true);
				},
				success: function(data){
					if(data == 1){
						showeducation();
						showForm('editeducation');
					}else{
						$("#editeducationmsg").html("*Something Error Please Try After Some Time Later.");
					}
				},
				complete: function(){
					$('#editeducationBtn').attr('disabled', false);
				}
			});
	    }
	</script>
</body>
</html>
<?php } ?>