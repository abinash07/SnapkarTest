<?php
session_start();
if(!isset($_SESSION["sbuserid"])){
header("location:login");
}else{
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@700&family=Roboto&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="../assets/css/style.css">
	<style>
		.addp{
			width: 95%;
			margin:10px 2.5%;
			border-radius: 5px;
			box-shadow: 0 1px 3px #c7c7c7;
		}
		.addp form{
			width: 95%;
			margin: 10px 2.5%;
		}
		#formhead{
			padding-top: 15px;
			text-align: center;
			font-family: 'Open Sans', sans-serif;
		}
		form lable{
			color: #262626;
			font-size: 14px;
			font-family: 'Open Sans', sans-serif;
		}
		.addp input[type=text], input[type=date]{
			width: 100%;
			color: #495057;
			padding: 12px 10px;
			margin: 10px 0 20px 0;
			display: inline-block;
			border: 1px solid #F0F0F0;
			box-sizing: border-box;
			outline: none;
			border-radius: 5px;
			-webkit-transition: 0.5s;
			transition: 0.5s;
		}
		.addp input:focus { 
			border-color: #0b7dda;
			box-shadow: 0 0 10px #0b7dda;
		}
		.addp textarea{
			width: 100%;
			color: #495057;
			margin-top: 10px;
			margin-bottom: 20px;
			border: 1px solid #F0F0F0;
			outline: none;
			border-radius: 5px;
			-webkit-transition: 0.5s;
			transition: 0.5s;
			padding: 12px 10px;
			box-sizing: border-box;
			font-size: 14px;
			line-height: 1.5;
			font-family: 'Roboto', sans-serif;
		}
		.addp textarea:focus { 
			border-color: #0b7dda;
			box-shadow: 0 0 10px #0b7dda;
		}
		select{
			width: 100%;
			padding: 12px 10px;
			border: 1px solid #ccc;
			margin-bottom: 15px;
			margin-top: 5px;
			cursor : pointer;
			outline: none;
			border-radius: 5px;
			-webkit-transition: 0.5s;
			transition: 0.5s;
			background-color: #FFFFFF;
			font-family: 'Roboto', sans-serif;
		}
		select:focus { 
			border-color: #0b7dda;
			box-shadow: 0 0 10px #0b7dda;
		}
		.addp button{
			background-color: #1877F2;
			color: white;
			padding: 12px 20px;
			border: none;
			cursor: pointer;
			text-align: center;
			width: 100%;
			margin: 10px 0 15px 0;
			border-radius: 5px;
			position: relative;
		}
		.addp button:hover {
			opacity: 0.8;
		}
		#errormsg{
			color: red;
			font-size: 14px;
		}
		#information {
		    color: #8E8E8E;
		    font-size: 12px;
		    margin: -10px 0 20px 0;
		}
	</style>
</head>
<body>
	<?php
		require_once('../connect.php');
		$slamuserid = $_SESSION["sbuserid"]; 
		$query = "select * from user where userid='$slamuserid'";
		$run = mysqli_query($con,$query);
		$row = mysqli_fetch_array($run);
		$name = $row['name'];
		$username = $row['username'];
		$userid = $row['userid'];
		$image = $row['image'];
		$verify = $row['verify'];
	?>
	<div class="top">
		<p id="bar" onclick="opennav()" ><i class="fa fa-long-arrow-left"></i></p>
		<a id="snap" href="<?php echo $baseurl; ?>/index">About me</a>
		<a id="img" href="<?php echo $baseurl; ?>/home/myaccount"><img src="<?php echo $baseurl; ?>/profile/<?php echo $image; ?>"></a>
		<a id="card"href="home/addpost"><i class="fa fa-th"></i></a>
		<a id="top29" href="index">Search</a>
		<a id="top29" href="home/addpost">New Post</a>
		<a id="top29" href="home/explore">Explore</a>
		<a id="top29" href="index">Home</a>
	</div>
	<div class="space"></div>

	<section>
		<div class="leftbar">
			<br>
			<a href="index.php"> <i id="ioconf" class="fa fa-home"></i> Home</a>
			<a href="home/myaccount"><i id="ioconf" class="fa fa-user-plus"></i> My Account</a>
			<a href="home/myaccount"><i id="ioconf" class="fa fa-user-circle-o"></i> My Posts</a>
			<a href="home/addpost"><i id="ioconf" class="fa fa-plus"></i> Create New Post</a>
			<hr>
			<a href="home/search"><i id="ioconf" class="fa fa-search"></i> Search</a>
			<a href="home/saved"><i id="ioconf" class="fa fa-bookmark-o"></i> My Saved </a>
			<a href="home/explore"><i id="ioconf" class="fa fa-compass"></i> Explore</a>
			<a href="home/addpost"><i id="ioconf" class="fa fa-plus"></i> New Post</a>
			<hr>
			<a href="aboutus"><i id="ioconf" class="fa fa-info-circle"></i> About us</a>
			<a href="mailto:thesnapkar@gmail.com"><i id="ioconf" class="fa fa-envelope"></i> Contact us</a>
			<a href="term"><i id="ioconf" class="fa fa-legal"></i> Term & Condition</a>
			<a href="privacy"><i id="ioconf" class="fa fa-lock"></i> Privacy policy</a>
		</div>
		<div id="cover"></div>
		<article>
			<?php
				$query = "SELECT * FROM aboutme WHERE userid='$slamuserid'";
				$run = mysqli_query($con, $query);
				$row = mysqli_fetch_array($run);
			?>
			<div class="addp">
				<p id="formhead">Create New Slam</p>
				<form id="aboutForm">

					<lable>Bio</lable>
					<textarea rows="2" name="bio" id="bio" placeholder="Say something about yourself" required><?php echo @$row['bio']; ?></textarea>

					<lable>Occupation</lable>
					<input type="text" id="occupation" name="occupation" placeholder="Ex: Student, Engineer, Doctor, Teacher" value="<?php echo @$row['occupation']; ?>" required>

					<lable>Local Name</lable>
					<input type="text" id="localname" name="localname" placeholder="Enter your local name" value="<?php echo @$row['localname']; ?>" required>


					<lable>Date of birth</lable>
					<input type="date" id="dob" name="dob" value="<?php echo @$row['dob']; ?>" required>

					<lable>Living city</lable>
					<input type="text" id="livingcity" name="livingcity" placeholder="Enter your living city" value="<?php echo @$row['living']; ?>" required>

					<lable>Home town</lable>
					<input type="text" id="hometown" name="hometown" placeholder="Enter your home town" value="<?php echo @$row['home']; ?>" required>

					<lable>Website</lable>
					<input type="text" id="website" name="website" placeholder="Enter your website" value="<?php echo @$row['website']; ?>" >

					<p id="errormsg"></p>
					<button id="aboutBtn" type="submit" name="submit"><div id="loader"><div class="spnier"></div></div> CREATE</button>
				</form>
			</div>
		</article>
	</section>
	<?php include('../bottom.php'); ?>
	<script>
		const opennav = () =>{
			history.go(-1);
		}
		$('#aboutForm').submit(function(e){
		e.preventDefault();
		var formdata = new FormData(this);
			$.ajax({
				url : "ajax/editbio",
				type : "POST",
				enctype: "multipart/form-data",
				data: formdata,
				processData: false,
				contentType: false,
				beforeSend: function(){
		            $("#cover").show();
		            $("#loader").show();
				},
				success: function(data){
					if(data == 1){
						location.href='editinfo';
					}else{
						$("#errormsg").html("*Something Error Please Try After Some Time Later.");
					}
				},
				complete: function(){
		            $("#cover").hide();
		            $("#loader").hide();
				}
			});
		});
	</script>
</body>
</html>
<?php } ?>