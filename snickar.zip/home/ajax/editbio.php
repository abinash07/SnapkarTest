<?php
    session_start();
    require_once("../../connect.php");
    if(isset($_POST['bio']) && isset($_POST['occupation']) && isset($_POST['localname']) && isset($_POST['dob']) && isset($_POST['livingcity']) && isset($_POST['hometown']) && isset($_POST['website'])){
        
        $userid = $_SESSION['sbuserid'];

        $bio = mysqli_real_escape_string($con,$_POST['bio']);
        $bio = htmlentities($bio);

        $occupation = mysqli_real_escape_string($con,$_POST['occupation']);
        $occupation = htmlentities($occupation);

        $localname = mysqli_real_escape_string($con,$_POST['localname']);
        $localname = htmlentities($localname);

        $dob = mysqli_real_escape_string($con,$_POST['dob']);
        $dob = htmlentities($dob);

        $livingcity = mysqli_real_escape_string($con,$_POST['livingcity']);
        $livingcity = htmlentities($livingcity);

        $hometown = mysqli_real_escape_string($con,$_POST['hometown']);
        $hometown = htmlentities($hometown);

        $website = mysqli_real_escape_string($con,$_POST['website']);
        $website = htmlentities($website);

        $query1 = "select * from aboutme where userid='$userid'";
        $run = mysqli_query($con,$query1);
        if(mysqli_num_rows($run) > 0){
            $query2 ="update aboutme set bio='$bio',occupation='$occupation',localname='$localname',dob='$dob',living='$livingcity',home='$hometown',website='$website' where userid='$userid'";
        }else{
            $query2 ="insert into aboutme (userid,bio,occupation,localname,dob,living,home,website) values ('$userid','$bio','$occupation','$localname','$dob','$livingcity','$hometown','$website')";
        }
        if(mysqli_query($con,$query2)){
            echo 1;
        }else{
            echo 0;
        }
    }
?>